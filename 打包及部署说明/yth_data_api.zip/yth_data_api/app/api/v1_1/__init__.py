from flask import Blueprint

api_bp_v1_1 = Blueprint("api_bp_v1_1", __name__)